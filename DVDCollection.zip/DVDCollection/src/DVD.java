
public class DVD {
	double moviePrice;
	int MLength;
	int HLength;
	String movieTitle;
	private DVD(String name)
	{
		System.out.println("Directed by " + name);
		
	}
	private void setTitle(String title)
	{
		movieTitle = title;
	}
	private String getTitle()
	{
		System.out.println(movieTitle + "!");
		return movieTitle;
	}
	
	private void setLength(int hour, int minute)
	{
		HLength = hour;
		MLength = minute;
	}
	
	private void getRuntime()
	{
		System.out.println("With a runtime of " + HLength + " Hour and " + MLength + " minutes");
	}
	
	private void setPrice(double price)
	{
		moviePrice = price;
	}
	private double getPrice()
	{
		System.out.println("Buy now for �" + moviePrice);
		return moviePrice;
	}
	
	
	public static void main(String []args)
			{
		DVD movie = new DVD("Jim Thorne");
		movie.setTitle("Magic Stars");
		movie.getTitle();
		movie.setLength(1, 33);
		movie.getRuntime();
		movie.setPrice(12.99);
		movie.getPrice();
			}
}

