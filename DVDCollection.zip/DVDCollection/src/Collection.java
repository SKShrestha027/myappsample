
public class Collection 
{
	double moviePrice;
	private Collection(String name)
	{
		System.out.println("Directed by " + name);
		
	}
	private void setLength()
	{
		
	}
	
	private void setPrice(double price)
	{
		moviePrice = price;
	}
	private double getPrice()
	{
		System.out.println("Buy now for �" + moviePrice);
		return moviePrice;
	}
	
	
	public static void main(String []args)
			{
		Collection movie = new Collection("Jim Thorne");
		movie.setPrice(12.99);
		movie.getPrice();
			}
}
